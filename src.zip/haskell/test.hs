outer a = 
 	let mid b = 
 		let inner c = c + 1
 		in inner b + 2
  	in mid a + 3

ggT a b = if b == 0 then a else ggT b (mod a b)

ggT' a b = case b of 
			0 -> a
			_ -> ggT' b (mod a b)

ggT'' a 0 = a
ggT'' a b = ggT'' b (mod a b)

ggT''' a b  | b == 0 	= a
			| otherwise = ggT''' b (mod a b) 

outer' a b =
  let inner c = a + b + c
  in inner 1

-- y "Operator"
y f = f (y f)

fac = y (\f n -> if n > 0 then n * f (n - 1) else 1)

newtype Euro1 = Euro1 Int
newtype Cent1 = Cent1 Int

type Euro = Int
type Cent = Int
type Preis = (Euro, Cent)

type Tupel = (Int, Int)

add :: Euro -> Euro -> Euro
add a b = a + b

add' :: Euro -> Cent -> Int
add' a b = a + b

primes :: [Integer]-> Int -> [Integer]
primes _      0 = []
primes (p:xs) i = (:) p $primes [x|x<- xs, mod x p > 0] $i + 1


primes' = sieves [2..]
  where
    sieves (p:xs) = p:sieves [x|x<- xs, mod x p > 0]